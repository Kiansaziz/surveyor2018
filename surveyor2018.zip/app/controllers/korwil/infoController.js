(function(){

    app.controller('infoController', function($scope){

      // Script goes here

    });



}());
